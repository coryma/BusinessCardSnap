// cmBusinessCardOcrUpload.js
import { LightningElement, api, track } from 'lwc';
import initBatchAndPersist from '@salesforce/apex/CM_BusinessCard_Controller.initBatchAndPersist';
import getSeedVersionIdsByBatch from '@salesforce/apex/CM_BusinessCard_Controller.getSeedVersionIdsByBatch';

export default class CmBusinessCardOcrUpload extends LightningElement {
  @api flowOutputBatchId;         // 給 Flow（舊流程用）
  @api varContentVersionIDs = '[]'; // 給 Flow（新流程用，JSON 陣列）

  @track batchId;
  @track fileCount = 0;
  @track errMsg;
  @track isLoading = false;

  async handleUploadFinished(event) {
    this.errMsg = null;
    const files = event.detail.files || [];
    this.fileCount = files.length;
    if (!files.length) return;

    try {
      this.isLoading = true;
      // 這裡拿到的是 ContentDocumentId 069…，後端會自動接受 068/069 混合
      const contentVersionIdsOrDocIds = files.map(f => f.documentId);

      const res = await initBatchAndPersist({ contentVersionIds: contentVersionIdsOrDocIds });
      this.batchId = res?.batchId;
      this.flowOutputBatchId = this.batchId;

      // 立刻把此批的種子圖片 068 撈出來，提供新流程使用
      const verIds = await getSeedVersionIdsByBatch({ batchId: this.batchId });
      this.varContentVersionIDs = JSON.stringify(verIds || []);

      // 通知 Flow（可選）
      this.dispatchEvent(new CustomEvent('valuechange', {
        detail: { batchId: this.flowOutputBatchId, versionIdsJson: this.varContentVersionIDs }
      }));
    } catch (e) {
      this.errMsg = (e && e.body && e.body.message) ? e.body.message : (e?.message || '發生未知錯誤');
    } finally {
      this.isLoading = false;
    }
  }
}
