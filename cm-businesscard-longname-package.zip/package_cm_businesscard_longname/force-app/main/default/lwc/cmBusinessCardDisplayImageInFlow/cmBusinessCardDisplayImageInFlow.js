import { LightningElement, api, track, wire } from 'lwc';
import getDocIdFromVersion from '@salesforce/apex/CM_BusinessCard_Image_Helper.getDocIdFromVersion';

export default class CmBusinessCardDisplayImageInFlow extends LightningElement {
  // ===== Inputs =====
  @api title = '名片圖片';
  @api altText = '名片圖片';
  @api contentVersionId;      // 068… （可只給它）
  @api contentDocumentId;     // 069… （也可直接給）
  @api width = '100%';        // '100%' / '600px'
  @api height = 'auto';       // 'auto' / '300px'
  @api objectFit = 'contain'; // contain | cover | fill | none | scale-down
  @api borderRadius = '6px';
  @api showDownloadLink = false;

  // 相容：若外部已組好完整 URL 也可直接傳進來
  @api imageUrl;              // 完整圖片 URL（優先使用）
  @api imageStyle;            // 自訂 CSS 字串，例如 "max-width:100%;border-radius:8px;"

  // ===== Outputs =====
  @api resolvedUrl;           // 成功顯示的實際 URL
  @api loadStatus = '';       // '', 'loaded', 'failed'

  // ===== State =====
  @track isLoading = false;
  @track errorMsg;
  _candidates = [];
  _idx = 0;

  // 取得 069（若只給 068）
  @wire(getDocIdFromVersion, { anyId: '$contentVersionId' })
  wiredDoc({ data, error }) {
    if (data && !this.contentDocumentId) {
      this.contentDocumentId = data;
    }
    // 線上/Flow 設定好後，若還沒準備候選清單就準備一次
    if (!this._candidates.length) {
      this.prepareCandidates();
    }
  }

  // ===== 計算屬性（注意避免與 @api imageStyle 衝突） =====
  get containerStyle() {
    return `width:${this.width};height:${this.height};`;
  }
  get computedImageStyle() {
    // 允許外部覆寫 CSS（若未傳入則用內建）
    if (this.imageStyle && this.imageStyle.trim()) return this.imageStyle;
    return `width:100%;height:100%;object-fit:${this.objectFit};border-radius:${this.borderRadius};display:block;`;
  }
  get imgUrl() {
    return this._candidates.length ? this._candidates[this._idx] : null;
  }
  get showDownload() {
    return !!this.showDownloadLink && !!this.downloadUrl;
  }

  // ===== Base prefix：Experience Cloud 支援 =====
  get basePrefix() {
    try {
      return window.location.pathname.includes('/sfsites/') ? '/sfsites/c' : '';
    } catch {
      return '';
    }
  }
  abs(path) {
    // 行動版使用絕對 URL 較穩
    try { return `${window.location.origin}${path}`; }
    catch { return path; }
  }

  // ===== Shepherd URLs =====
  buildVersionInline(versionId) {
    return this.abs(`${this.basePrefix}/sfc/servlet.shepherd/version/download/${versionId}?asInline=1`);
  }
  buildRendition(versionId, rendition) {
    return this.abs(`${this.basePrefix}/sfc/servlet.shepherd/version/renditionDownload?rendition=${rendition}&versionId=${versionId}`);
  }
  buildVersionDownload(versionId) {
    return this.abs(`${this.basePrefix}/sfc/servlet.shepherd/version/download/${versionId}`);
  }
  buildDocumentDownload(docId) {
    return this.abs(`${this.basePrefix}/sfc/servlet.shepherd/document/download/${docId}`);
  }

  get downloadUrl() {
    if (this.contentVersionId) return this.buildVersionDownload(this.contentVersionId);
    if (this.contentDocumentId) return this.buildDocumentDownload(this.contentDocumentId);
    return null;
  }

  // ===== 初始化/更新 =====
  connectedCallback() {
    this.prepareCandidates();
  }
  renderedCallback() {
    // Flow 先塞值再 render；若還沒建好候選清單，這裡補一次
    if (!this._candidates.length && (this.contentVersionId || this.contentDocumentId || this.imageUrl)) {
      this.prepareCandidates();
    }
  }

  @api refresh() {
    this.prepareCandidates();
  }

  prepareCandidates() {
    this.errorMsg = undefined;
    this.loadStatus = '';
    this.isLoading = true;
    this._idx = 0;
    this._candidates = [];

    // 1) 外部已給完整 URL → 最高優先
    if (this.imageUrl && this.imageUrl.trim()) {
      this._candidates.push(this.imageUrl.trim());
    }

    // 2) 以 068 為主的顯示（行動端最穩：inline）
    if (this.contentVersionId) {
      this._candidates.push(this.buildVersionInline(this.contentVersionId));       // ✅ 首選
      this._candidates.push(this.buildRendition(this.contentVersionId, 'THUMB1200BY900')); // 常見縮圖
      this._candidates.push(this.buildRendition(this.contentVersionId, 'THUMB720BY480'));  // 退一步縮圖
      this._candidates.push(this.buildVersionDownload(this.contentVersionId));     // 最終備援
    }

    // 3) 若有 069：再補一個下載備援
    if (this.contentDocumentId) {
      this._candidates.push(this.buildDocumentDownload(this.contentDocumentId));
    }

    if (!this._candidates.length) {
      this.isLoading = false;
      this.errorMsg = '缺少 ContentVersionId / ContentDocumentId / ImageUrl';
    }
  }

  // ===== 事件處理 =====
  onImgLoad() {
    this.isLoading = false;
    this.errorMsg = undefined;
    this.loadStatus = 'loaded';
    this.resolvedUrl = this.imgUrl;
  }
  onImgError() {
    const next = this._idx + 1;
    if (next < this._candidates.length) {
      this._idx = next;   // 換下一個候選 URL（模板會自動刷新 <img src>）
      return;
    }
    this.isLoading = false;
    this.loadStatus = 'failed';
    this.errorMsg = '圖片無法顯示（可能格式不支援或權限不足）';
  }
  openDownload() {
    const url = this.downloadUrl;
    if (url) window.open(url, '_blank'); // eslint-disable-line no-restricted-globals
  }
}
