import { LightningElement, api, track } from 'lwc';
import getBatchProgress from '@salesforce/apex/CM_BusinessCard_Controller.getBatchProgress';
import getCardsByBatch   from '@salesforce/apex/CM_BusinessCard_Controller.getCardsByBatch';
import getProgressByVersionId from '@salesforce/apex/CM_BusinessCard_Controller.getProgressByVersionId';
import getCardsByVersionId    from '@salesforce/apex/CM_BusinessCard_Controller.getCardsByVersionId';
import findAccountDuplicates  from '@salesforce/apex/CM_BusinessCard_Controller.findAccountDuplicates';

const POLL_MS      = 2000;   // 後端輪詢頻率
const ANIM_TOTAL_MS= 12000;  // 進度條固定 12 秒一輪
const ANIM_TICK_MS = 100;    // 進度條更新頻率
const TIMEOUT_MS   = 20000;  // 逾時保底：到點就結束等待
const MODE_LEAD    = 'Lead';
const MODE_CONTACT = 'Contact';

export default class CmBusinessCardReviewAsync extends LightningElement {
  // ===== 兩種模式：給 contentVersionId（068/069）或 batchId，二選一 =====
  _contentVersionId;
  _batchId;

  @api
  get contentVersionId() { return this._contentVersionId; }
  set contentVersionId(v) {
    this._contentVersionId = v;
    this.tryStart(); // 參數晚到也能及時啟動
  }

  @api
  get batchId() { return this._batchId; }
  set batchId(v) {
    this._batchId = v;
    this.tryStart(); // 參數晚到也能及時啟動
  }

  @api leadSource = 'BusinessCard';
  @api flowOutputCardsJsonEdited;

  @track progress = { total: 0, recognized: 0, failed: 0, status: 'EMPTY' };
  @track cards = [];
  @track errMsg;
  @track matchErrMsg;
  @track uiProgress = 0;

  _pollTimer;
  _animTimer;
  _animStart = 0;
  _started   = false;
  _finished  = false;
  _t0        = 0;

  // 狀態切換
  get useVersionMode() { return !!this._contentVersionId; }
  get hasCards()       { return (this.cards?.length || 0) > 0; }
  get isReady()        { return this.hasCards; }
  get isNoCards()      { return !this.hasCards && this._finished; } // 已完成但沒有卡片
  get isWaiting()      { return !this.isReady && !this.isNoCards; }

  // 以進度描述即可，百分比由動畫呈現
  get progressLabel() {
    const t = this.progress?.total || 0;
    const r = this.progress?.recognized || 0;
    const f = this.progress?.failed || 0;
    return t ? `正在辨識名片中…（已處理 ${r}/${t}${f ? '，失敗 ' + f : ''}）` : '正在準備中…';
  }

  connectedCallback() {
    this.tryStart();
  }
  disconnectedCallback() {
    this.stopAnimation();
    if (this._pollTimer) clearTimeout(this._pollTimer);
  }

  // ===== 啟動判斷：有任一 Id 且尚未啟動，就開始 =====
  tryStart() {
    if (this._started) return;
    if (!this._contentVersionId && !this._batchId) return;

    this._started = true;
    this._finished = false;
    this._t0 = Date.now();
    this.matchErrMsg = null;

    this.startAnimation();
    this.schedulePoll(0);
  }

  // ===== 12 秒循環動畫 =====
  startAnimation() {
    this.stopAnimation();
    this._animStart = Date.now();
    this._animTimer = setInterval(() => {
      const elapsed = Date.now() - this._animStart;
      const pct = Math.floor(((elapsed % ANIM_TOTAL_MS) / ANIM_TOTAL_MS) * 100);
      this.uiProgress = (this._finished || this.isReady) ? 100 : pct;
    }, ANIM_TICK_MS);
  }
  stopAnimation() {
    if (this._animTimer) clearInterval(this._animTimer);
    this._animTimer = null;
    this.uiProgress = 100;
  }

  // ===== 後端輪詢（完成或逾時就結束）=====
  schedulePoll(delay) {
    if (this._pollTimer) clearTimeout(this._pollTimer);
    this._pollTimer = setTimeout(() => this.pollOnce(), delay);
  }

  async pollOnce() {
    try {
      let p, rows;
      if (this.useVersionMode) {
        [p, rows] = await Promise.all([
          getProgressByVersionId({ contentVersionIdOrDocId: this._contentVersionId }),
          getCardsByVersionId({ contentVersionIdOrDocId: this._contentVersionId })
        ]);
      } else {
        [p, rows] = await Promise.all([
          getBatchProgress({ batchId: this._batchId }),
          getCardsByBatch({ batchId: this._batchId })
        ]);
      }

      this.progress = p || { total: 0, recognized: 0, failed: 0, status: 'EMPTY' };

      // 1) 有卡片就直接完成
      if (Array.isArray(rows) && rows.length > 0) {
        this.cards = this.attachKeys(rows);
        await this.decorateCardsWithMatches();
        this.syncOutput();
        this.finishPolling();
        return;
      }

      // 2) 沒卡片但進度顯示「全部完成」 ⇒ 視為「完成但沒有名片」
      const allDone = (this.progress?.status === 'ALL_RECOGNIZED') && (this.progress?.total || 0) > 0;
      if (allDone) {
        this.cards = [];
        this.syncOutput();
        this.finishPolling(true);
        return;
      }

      // 3) 逾時保底：到點再拉一次資料，仍無 → 結束（避免卡住）
      const timedOut = (Date.now() - this._t0) >= TIMEOUT_MS;
      if (timedOut) {
        const rows2 = await this.fetchCardsOnce(); // 再確認一次
        if (Array.isArray(rows2) && rows2.length > 0) {
          this.cards = this.attachKeys(rows2);
          await this.decorateCardsWithMatches();
          this.syncOutput();
        } else {
          this.cards = []; // 當作無名片結束
          this.matchErrMsg = null;
          this.syncOutput();
        }
        this.finishPolling(true);
        return;
      }

      // 4) 繼續輪詢
      this.schedulePoll(POLL_MS);

    } catch (e) {
      this.errMsg = e?.body?.message || e?.message || '取得進度失敗';
      // 錯誤也不立刻卡死：等下一輪
      this.schedulePoll(POLL_MS);
    }
  }

  async fetchCardsOnce() {
    try {
      if (this.useVersionMode) {
        return await getCardsByVersionId({ contentVersionIdOrDocId: this._contentVersionId });
      }
      return await getCardsByBatch({ batchId: this._batchId });
    } catch {
      return [];
    }
  }

  async decorateCardsWithMatches() {
    if (!Array.isArray(this.cards) || this.cards.length === 0) {
      this.matchErrMsg = null;
      return;
    }

    const companyNames = this.cards.map(card => (card && card.Company) ? card.Company : null);
    try {
      const response = await findAccountDuplicates({ companyNames });
      const matches = Array.isArray(response) ? response : [];
      const updated = this.cards.map((card, index) => this.decorateCardWithMatches(card, matches[index]));
      this.cards = updated;
      this.matchErrMsg = null;
    } catch (error) {
      // 若查詢發生錯誤，記錄訊息但不要阻斷流程，並重置為預設狀態
      this.matchErrMsg = error?.body?.message || error?.message || '比對現有客戶失敗，請稍後重試。';
      this.cards = this.cards.map(card => this.decorateCardWithMatches(card, null));
    }
  }

  decorateCardWithMatches(card, match) {
    const options = this.buildAccountOptions(match);
    const hasMatches = options.length > 0;
    const createAs = this.normalizeCreateMode(card?.CreateAs, hasMatches);

    let selectedAccountId = card?.ExistingAccountId || null;
    if (createAs === MODE_CONTACT && hasMatches) {
      const exists = options.some(opt => opt.value === selectedAccountId);
      if (!exists) {
        selectedAccountId = options.length === 1 ? options[0].value : null;
      }
    } else {
      selectedAccountId = null;
    }

    return {
      ...card,
      CreateAs: createAs,
      ExistingAccountId: selectedAccountId,
      accountOptions: options,
      createOptions: this.buildCreateOptions(hasMatches),
      hasAccountMatches: hasMatches,
      showAccountPicker: createAs === MODE_CONTACT && hasMatches
    };
  }

  buildAccountOptions(match) {
    if (!match || !Array.isArray(match.accounts)) {
      return [];
    }

    return match.accounts
      .filter(acc => acc && acc.accountId)
      .map(acc => ({
        label: this.formatAccountLabel(acc),
        value: acc.accountId
      }));
  }

  buildCreateOptions(hasMatches) {
    const options = [
      { label: '建立新的潛在客戶 (Lead)', value: MODE_LEAD }
    ];
    if (hasMatches) {
      options.push({ label: '連結現有客戶並建立聯絡人 (Contact)', value: MODE_CONTACT });
    }
    return options;
  }

  normalizeCreateMode(value, hasMatches) {
    const token = (value || '').toLowerCase();
    if (hasMatches && token === MODE_CONTACT.toLowerCase()) {
      return MODE_CONTACT;
    }
    return MODE_LEAD;
  }

  formatAccountLabel(option) {
    const parts = [option.name];
    const region = [option.billingCity, option.billingCountry].filter(Boolean).join(', ');
    if (region) {
      parts.push(`· ${region}`);
    }
    if (option.phone) {
      parts.push(`· ${option.phone}`);
    }
    return parts.filter(Boolean).join(' ');
  }

  finishPolling(noCards = false) {
    this._finished = true;
    this.stopAnimation();
    if (this._pollTimer) {
      clearTimeout(this._pollTimer);
      this._pollTimer = null;
    }
    // 如需通知 Flow，可發事件：
    // this.dispatchEvent(new CustomEvent('done', { detail: { noCards } }));
  }

  // ===== UI & Flow 輸出 =====
  attachKeys(rows) {
    return (rows || []).map((r, i) => {
      const a = (r.Email || '').toLowerCase();
      const b = (r.Company || '').toLowerCase();
      const c = (r.FirstName || '').toLowerCase() + (r.LastName || '').toLowerCase();
      const key = `${i}-${a}-${b}-${c}`;
      const createAs = this.normalizeCreateMode(r?.CreateAs, false);
      return {
        ...r,
        CreateAs: createAs,
        ExistingAccountId: r?.ExistingAccountId || null,
        accountOptions: [],
        createOptions: this.buildCreateOptions(false),
        hasAccountMatches: false,
        showAccountPicker: false,
        _key: key
      };
    });
  }
  onDescChange(e) {
    const idx = Number(e.target.dataset.index);
    if (Number.isNaN(idx) || !this.cards[idx]) {
      return;
    }
    this.cards[idx].Description = e.detail.value;
    this.cards = [...this.cards];
    this.syncOutput();
  }
  onCreateModeChange(e) {
    const idx = Number(e.target.dataset.index);
    if (Number.isNaN(idx) || !this.cards[idx]) {
      return;
    }
    const selectedMode = this.normalizeCreateMode(e.detail.value, this.cards[idx].hasAccountMatches);
    const card = this.cards[idx];
    card.CreateAs = selectedMode;
    if (selectedMode === MODE_CONTACT && card.hasAccountMatches) {
      if (!card.ExistingAccountId && card.accountOptions.length === 1) {
        card.ExistingAccountId = card.accountOptions[0].value;
      }
      card.showAccountPicker = true;
    } else {
      card.ExistingAccountId = null;
      card.showAccountPicker = false;
    }
    this.cards = [...this.cards];
    this.syncOutput();
  }
  onAccountPickChange(e) {
    const idx = Number(e.target.dataset.index);
    if (Number.isNaN(idx) || !this.cards[idx]) {
      return;
    }
    const value = e.detail.value;
    this.cards[idx].ExistingAccountId = value || null;
    this.cards = [...this.cards];
    this.syncOutput();
  }
  syncOutput() {
    try {
      const sanitized = (this.cards || []).map(card => {
        const payload = { ...card };
        delete payload._key;
        delete payload.accountOptions;
        delete payload.createOptions;
        delete payload.hasAccountMatches;
        delete payload.showAccountPicker;
        return payload;
      });
      this.flowOutputCardsJsonEdited = JSON.stringify(sanitized);
    } catch {
      this.flowOutputCardsJsonEdited = '[]';
    }
  }

  @api validate() {
    // 完成（有或無卡片）都允許下一步；若你要「無卡片擋住」，把 isNoCards 改成不通過
    if (this.isWaiting) {
      return { isValid: false, errorMessage: '名片辨識尚未完成，請稍候…' };
    }
    this.syncOutput();
    for (const card of this.cards || []) {
      if (card.CreateAs === MODE_CONTACT && (!card.ExistingAccountId || !card.ExistingAccountId.length)) {
        const name = card.Company || `${card.LastName || ''}${card.FirstName || ''}` || '該名片';
        return { isValid: false, errorMessage: `請為「${name}」選擇要連結的客戶。` };
      }
    }
    return { isValid: true };
  }
}
