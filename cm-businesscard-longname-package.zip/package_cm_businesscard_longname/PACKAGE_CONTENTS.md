# CM BusinessCard Long-Name Package Contents

This package is a renamed, isolated copy. The original `force-app` sources are untouched.

## Flows
- `force-app/main/default/flows/CM_BusinessCard_To_Lead.flow-meta.xml`
- `force-app/main/default/flows/CM_BusinessCard_Create_Record_From_Event.flow-meta.xml`

## Prompt Template
- `force-app/main/default/genAiPromptTemplates/CM_BusinessCard_Card_To_Lead.genAiPromptTemplate-meta.xml`

## Apex
- `force-app/main/default/classes/CM_BusinessCard_Controller.cls`
- `force-app/main/default/classes/CM_BusinessCard_Controller.cls-meta.xml`
- `force-app/main/default/classes/CM_BusinessCard_Ocr_Job.cls`
- `force-app/main/default/classes/CM_BusinessCard_Ocr_Job.cls-meta.xml`
- `force-app/main/default/classes/CM_BusinessCard_Json_Parser.cls`
- `force-app/main/default/classes/CM_BusinessCard_Json_Parser.cls-meta.xml`
- `force-app/main/default/classes/CM_BusinessCard_Parse_String_Array.cls`
- `force-app/main/default/classes/CM_BusinessCard_Parse_String_Array.cls-meta.xml`
- `force-app/main/default/classes/CM_BusinessCard_Image_Helper.cls`
- `force-app/main/default/classes/CM_BusinessCard_Image_Helper.cls-meta.xml`

## LWC
- `force-app/main/default/lwc/cmBusinessCardOcrUpload/*`
- `force-app/main/default/lwc/cmBusinessCardReviewAsync/*`
- `force-app/main/default/lwc/cmBusinessCardDisplayImageInFlow/*`
- `force-app/main/default/lwc/fsc_drawLine/*` (kept original name)

## Objects / Platform Event
- `force-app/main/default/objects/CM_BusinessCard__c/CM_BusinessCard__c.object-meta.xml`
- `force-app/main/default/objects/CM_BusinessCard__c/fields/*`
- `force-app/main/default/objects/Business_Card_Processed__e.object-meta.xml`
- `force-app/main/default/objects/Business_Card_Processed__e/fields/*`

## Manifest
- `manifest/package.xml`
